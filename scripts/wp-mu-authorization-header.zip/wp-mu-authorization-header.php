<?php
/**
 * Plugin Name: Authorization header passthrough
 * Description: The host strips the Authorization header before WordPress sees it, so Application Passwords cannot log in over the REST API. This reads the same value from an X-Authorization header instead. Upload to wp-content/mu-plugins/ on cms.dkjonah.com.
 * Author: dkjonah.com build
 */

if ( empty( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
	if ( ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
		$_SERVER['HTTP_AUTHORIZATION'] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
	} elseif ( ! empty( $_SERVER['HTTP_X_AUTHORIZATION'] ) ) {
		$_SERVER['HTTP_AUTHORIZATION'] = $_SERVER['HTTP_X_AUTHORIZATION'];
	}
}
